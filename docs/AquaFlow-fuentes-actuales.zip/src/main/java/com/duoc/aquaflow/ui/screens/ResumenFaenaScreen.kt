package com.duoc.aquaflow.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.duoc.aquaflow.domain.ReglasDecision
import com.duoc.aquaflow.domain.Reglas
import com.duoc.aquaflow.model.Decision
import com.duoc.aquaflow.model.EstadoEquipo
import com.duoc.aquaflow.model.RegistroDecision
import com.duoc.aquaflow.model.ResumenFaena
import com.duoc.aquaflow.model.Rol
import com.duoc.aquaflow.ui.components.SemaforoAst
import com.duoc.aquaflow.ui.components.SemaforoFaena
import com.duoc.aquaflow.ui.components.SemaforoSalud
import com.duoc.aquaflow.viewmodel.ResumenFaenaViewModel

// Muestra todo lo recolectado y, si el usuario es de la jefatura, permite autorizar o rechazar.
// No decide nada: valida el ViewModel y calculan las reglas del dominio.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumenFaenaScreen(
    vm: ResumenFaenaViewModel,
    resumen: ResumenFaena,
    decision: RegistroDecision?,
    rol: Rol,
    nombreUsuario: String,
    onDecidir: (RegistroDecision) -> Unit,
    onVolver: () -> Unit,
    onFinalizar: () -> Unit
) {
    val ui by vm.ui.collectAsState()
    val resultado = ReglasDecision.resultado(resumen)
    val faltantes = ReglasDecision.faltantes(resumen)
    val apertura = resumen.apertura

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Resumen de faena") },
                navigationIcon = { TextButton(onClick = onVolver) { Text("Volver") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Semáforo global: solo aparece cuando están todas las partes
            if (resultado != null) SemaforoFaena(resultado)
            else Text("Resumen incompleto. Falta: ${faltantes.joinToString()}", color = MaterialTheme.colorScheme.error)

            Seccion("Apertura") {
                Text(apertura.centroCultivo.ifBlank { "Centro sin definir" })
                Text("${apertura.fecha} ${apertura.hora}".trim())
                Text("Buzo: ${apertura.buzoAsignado.ifBlank { "sin asignar" }}")
                Text("Supervisor: ${apertura.supervisorACargo.ifBlank { "sin asignar" }}")
            }

            Seccion("Checklist de equipos") {
                val items = resumen.checklist?.items.orEmpty()
                if (items.isEmpty()) Text("Sin registrar")
                items.forEach {
                    Text("• ${it.titulo}: ${it.estado.texto()}")
                    if (it.notas.isNotBlank()) Text("   Nota: ${it.notas}")
                }
                resumen.checklist?.let { Text("Fotos de evidencia: ${it.fotosEvidencia.size}") }
            }

            Seccion("AST") {
                val ast = resumen.ast
                if (ast == null) Text("Sin registrar") else {
                    Text(ast.tipologia)
                    Text("Pasos: ${ast.pasos.size} · Riesgos críticos: ${ast.pasos.count { it.critico }}")
                    if (ast.requiereNuevoAst) Text("Requiere un nuevo AST")
                    SemaforoAst(ast.resultado)
                }
            }

            Seccion("Salud (ficticia)") {
                val e = resumen.encuesta
                if (e == null) Text("Sin registrar") else {
                    Text("Presión ${e.sistolica}/${e.diastolica} · Saturación ${e.saturacion}%")
                    e.alertasEncuesta.forEach { Text("⚠ $it") }
                    SemaforoSalud(Reglas.nivelSalud(e.sistolica, e.diastolica, e.saturacion, e.alertasEncuesta.size))
                }
            }

            Seccion("Decisión") {
                when {
                    // Ya decidida: se muestra el registro y se cierra el formulario
                    decision != null -> {
                        Text("${decision.decision.texto} por ${decision.decididoPor}")
                        if (decision.motivo.isNotEmpty()) Text("Motivo: ${decision.motivo}")
                        Button(onClick = onFinalizar, modifier = Modifier.fillMaxWidth()) { Text("Ir al inicio") }
                    }
                    !ReglasDecision.puedeDecidir(rol) ->
                        Text("Solo la jefatura autoriza o rechaza la faena.")
                    else -> {
                        OutlinedTextField(
                            value = ui.motivo,
                            onValueChange = vm::cambiarMotivo,
                            label = { Text("Motivo (obligatorio al rechazar)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        ui.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { vm.decidir(Decision.AUTORIZADA, resumen, rol, nombreUsuario)?.let(onDecidir) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Autorizar") }
                            OutlinedButton(
                                onClick = { vm.decidir(Decision.RECHAZADA, resumen, rol, nombreUsuario)?.let(onDecidir) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Rechazar") }
                        }
                    }
                }
            }
        }
    }
}

// Tarjeta con título para cada parte del resumen
@Composable
private fun Seccion(titulo: String, contenido: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium)
            contenido()
        }
    }
}

private fun EstadoEquipo.texto() = when (this) {
    EstadoEquipo.CUMPLE -> "Cumple"
    EstadoEquipo.NO_CUMPLE -> "No cumple"
    EstadoEquipo.OBSERVADO -> "Observado"
    EstadoEquipo.PENDIENTE -> "Pendiente"
}